//
// Generated file, do not edit! Created by opp_msgc 3.3 from cl_msg.msg.
//

// Disable warnings about unused variables, empty switch stmts, etc:
#ifdef _MSC_VER
#  pragma warning(disable:4101)
#  pragma warning(disable:4065)
#endif

#include <iostream>
#include <sstream>
#include "cl_msg_m.h"

// Template rule which fires if a struct or class doesn't have operator<<
template<typename T>
std::ostream& operator<<(std::ostream& out,const T&) {return out;}

// Another default rule (prevents compiler from choosing base class' doPacking())
template<typename T>
void doPacking(cCommBuffer *, T& t) {
    throw new cException("Parsim error: no doPacking() function for type %s or its base class (check .msg and _m.cc/h files!)",opp_typename(typeid(t)));
}
template<typename T>
void doUnpacking(cCommBuffer *, T& t) {
    throw new cException("Parsim error: no doUnpacking() function for type %s or its base class (check .msg and _m.cc/h files!)",opp_typename(typeid(t)));
}

// Automatically supply array (un)packing functions
template<typename T>
void doPacking(cCommBuffer *b, T *t, int n) {
    for (int i=0; i<n; i++)
        doPacking(b,t[i]);
}
template<typename T>
void doUnpacking(cCommBuffer *b, T *t, int n) {
    for (int i=0; i<n; i++)
        doUnpacking(b,t[i]);
}
inline void doPacking(cCommBuffer *, cPolymorphic&) {}
inline void doUnpacking(cCommBuffer *, cPolymorphic&) {}

#define DOPACKING(T,R) \
    inline void doPacking(cCommBuffer *b, T R a) {b->pack(a);}  \
    inline void doPacking(cCommBuffer *b, T *a, int n) {b->pack(a,n);}  \
    inline void doUnpacking(cCommBuffer *b, T& a) {b->unpack(a);}  \
    inline void doUnpacking(cCommBuffer *b, T *a, int n) {b->unpack(a,n);}
#define _
DOPACKING(char,_)
DOPACKING(unsigned char,_)
DOPACKING(bool,_)
DOPACKING(short,_)
DOPACKING(unsigned short,_)
DOPACKING(int,_)
DOPACKING(unsigned int,_)
DOPACKING(long,_)
DOPACKING(unsigned long,_)
DOPACKING(float,_)
DOPACKING(double,_)
DOPACKING(long double,_)
DOPACKING(char *,_)
DOPACKING(const char *,_)
DOPACKING(opp_string,&)
//DOPACKING(std::string,&)
#undef _
#undef DOPACKING


Register_Class(ClusterMessage);

ClusterMessage::ClusterMessage(const char *name, int kind) : cMessage(name,kind)
{
    this->proto_var = 0;
    this->srcAddress_var = 0;
    this->destAddress_var = 0;
}

ClusterMessage::ClusterMessage(const ClusterMessage& other) : cMessage()
{
    unsigned int i;
    setName(other.name());
    operator=(other);
}

ClusterMessage::~ClusterMessage()
{
    unsigned int i;
}

ClusterMessage& ClusterMessage::operator=(const ClusterMessage& other)
{
    if (this==&other) return *this;
    unsigned int i;
    cMessage::operator=(other);
    this->proto_var = other.proto_var;
    this->srcAddress_var = other.srcAddress_var;
    this->destAddress_var = other.destAddress_var;
    return *this;
}

void ClusterMessage::netPack(cCommBuffer *b)
{
    cMessage::netPack(b);
    doPacking(b,this->proto_var);
    doPacking(b,this->srcAddress_var);
    doPacking(b,this->destAddress_var);
}

void ClusterMessage::netUnpack(cCommBuffer *b)
{
    cMessage::netUnpack(b);
    doUnpacking(b,this->proto_var);
    doUnpacking(b,this->srcAddress_var);
    doUnpacking(b,this->destAddress_var);
}

int ClusterMessage::getProto() const
{
    return proto_var;
}

void ClusterMessage::setProto(int proto_var)
{
    this->proto_var = proto_var;
}

int ClusterMessage::getSrcAddress() const
{
    return srcAddress_var;
}

void ClusterMessage::setSrcAddress(int srcAddress_var)
{
    this->srcAddress_var = srcAddress_var;
}

int ClusterMessage::getDestAddress() const
{
    return destAddress_var;
}

void ClusterMessage::setDestAddress(int destAddress_var)
{
    this->destAddress_var = destAddress_var;
}

class ClusterMessageDescriptor : public cStructDescriptor
{
  public:
    ClusterMessageDescriptor();
    virtual ~ClusterMessageDescriptor();
    ClusterMessageDescriptor& operator=(const ClusterMessageDescriptor& other);
    virtual cPolymorphic *dup() const {return new ClusterMessageDescriptor(*this);}

    virtual int getFieldCount();
    virtual const char *getFieldName(int field);
    virtual int getFieldType(int field);
    virtual const char *getFieldTypeString(int field);
    virtual const char *getFieldEnumName(int field);
    virtual int getArraySize(int field);

    virtual bool getFieldAsString(int field, int i, char *resultbuf, int bufsize);
    virtual bool setFieldAsString(int field, int i, const char *value);

    virtual const char *getFieldStructName(int field);
    virtual void *getFieldStructPointer(int field, int i);
    virtual sFieldWrapper *getFieldWrapper(int field, int i);
};

Register_Class(ClusterMessageDescriptor);

ClusterMessageDescriptor::ClusterMessageDescriptor() : cStructDescriptor("cMessage")
{
}

ClusterMessageDescriptor::~ClusterMessageDescriptor()
{
}

int ClusterMessageDescriptor::getFieldCount()
{
    return baseclassdesc ? 3+baseclassdesc->getFieldCount() : 3;
}

int ClusterMessageDescriptor::getFieldType(int field)
{
    if (baseclassdesc) {
        if (field < baseclassdesc->getFieldCount())
            return baseclassdesc->getFieldType(field);
        field -= baseclassdesc->getFieldCount();
    }
    switch (field) {
        case 0: return FT_BASIC;
        case 1: return FT_BASIC;
        case 2: return FT_BASIC;
        default: return FT_INVALID;
    }
}

const char *ClusterMessageDescriptor::getFieldName(int field)
{
    if (baseclassdesc) {
        if (field < baseclassdesc->getFieldCount())
            return baseclassdesc->getFieldName(field);
        field -= baseclassdesc->getFieldCount();
    }
    switch (field) {
        case 0: return "proto";
        case 1: return "srcAddress";
        case 2: return "destAddress";
        default: return NULL;
    }
}

const char *ClusterMessageDescriptor::getFieldTypeString(int field)
{
    if (baseclassdesc) {
        if (field < baseclassdesc->getFieldCount())
            return baseclassdesc->getFieldTypeString(field);
        field -= baseclassdesc->getFieldCount();
    }
    switch (field) {
        case 0: return "int";
        case 1: return "int";
        case 2: return "int";
        default: return NULL;
    }
}

const char *ClusterMessageDescriptor::getFieldEnumName(int field)
{
    if (baseclassdesc) {
        if (field < baseclassdesc->getFieldCount())
            return baseclassdesc->getFieldEnumName(field);
        field -= baseclassdesc->getFieldCount();
    }
    switch (field) {
        default: return NULL;
    }
}

int ClusterMessageDescriptor::getArraySize(int field)
{
    if (baseclassdesc) {
        if (field < baseclassdesc->getFieldCount())
            return baseclassdesc->getArraySize(field);
        field -= baseclassdesc->getFieldCount();
    }
    ClusterMessage *pp = (ClusterMessage *)p;
    switch (field) {
        default: return 0;
    }
}

bool ClusterMessageDescriptor::getFieldAsString(int field, int i, char *resultbuf, int bufsize)
{
    if (baseclassdesc) {
        if (field < baseclassdesc->getFieldCount())
            return baseclassdesc->getFieldAsString(field,i,resultbuf,bufsize);
        field -= baseclassdesc->getFieldCount();
    }
    ClusterMessage *pp = (ClusterMessage *)p;
    switch (field) {
        case 0: long2string(pp->getProto(),resultbuf,bufsize); return true;
        case 1: long2string(pp->getSrcAddress(),resultbuf,bufsize); return true;
        case 2: long2string(pp->getDestAddress(),resultbuf,bufsize); return true;
        default: return false;
    }
}

bool ClusterMessageDescriptor::setFieldAsString(int field, int i, const char *value)
{
    if (baseclassdesc) {
        if (field < baseclassdesc->getFieldCount())
            return baseclassdesc->setFieldAsString(field,i,value);
        field -= baseclassdesc->getFieldCount();
    }
    ClusterMessage *pp = (ClusterMessage *)p;
    switch (field) {
        case 0: pp->setProto(string2long(value)); return true;
        case 1: pp->setSrcAddress(string2long(value)); return true;
        case 2: pp->setDestAddress(string2long(value)); return true;
        default: return false;
    }
}

const char *ClusterMessageDescriptor::getFieldStructName(int field)
{
    if (baseclassdesc) {
        if (field < baseclassdesc->getFieldCount())
            return baseclassdesc->getFieldStructName(field);
        field -= baseclassdesc->getFieldCount();
    }
    switch (field) {
        default: return NULL;
    }
}

void *ClusterMessageDescriptor::getFieldStructPointer(int field, int i)
{
    if (baseclassdesc) {
        if (field < baseclassdesc->getFieldCount())
            return baseclassdesc->getFieldStructPointer(field, i);
        field -= baseclassdesc->getFieldCount();
    }
    ClusterMessage *pp = (ClusterMessage *)p;
    switch (field) {
        default: return NULL;
    }
}

sFieldWrapper *ClusterMessageDescriptor::getFieldWrapper(int field, int i)
{
    return NULL;
}

Register_Class(Start);

Start::Start(const char *name, int kind) : ClusterMessage(name,kind)
{
    this->round_var = 0;
}

Start::Start(const Start& other) : ClusterMessage()
{
    unsigned int i;
    setName(other.name());
    operator=(other);
}

Start::~Start()
{
    unsigned int i;
}

Start& Start::operator=(const Start& other)
{
    if (this==&other) return *this;
    unsigned int i;
    ClusterMessage::operator=(other);
    this->round_var = other.round_var;
    return *this;
}

void Start::netPack(cCommBuffer *b)
{
    ClusterMessage::netPack(b);
    doPacking(b,this->round_var);
}

void Start::netUnpack(cCommBuffer *b)
{
    ClusterMessage::netUnpack(b);
    doUnpacking(b,this->round_var);
}

int Start::getRound() const
{
    return round_var;
}

void Start::setRound(int round_var)
{
    this->round_var = round_var;
}

class StartDescriptor : public cStructDescriptor
{
  public:
    StartDescriptor();
    virtual ~StartDescriptor();
    StartDescriptor& operator=(const StartDescriptor& other);
    virtual cPolymorphic *dup() const {return new StartDescriptor(*this);}

    virtual int getFieldCount();
    virtual const char *getFieldName(int field);
    virtual int getFieldType(int field);
    virtual const char *getFieldTypeString(int field);
    virtual const char *getFieldEnumName(int field);
    virtual int getArraySize(int field);

    virtual bool getFieldAsString(int field, int i, char *resultbuf, int bufsize);
    virtual bool setFieldAsString(int field, int i, const char *value);

    virtual const char *getFieldStructName(int field);
    virtual void *getFieldStructPointer(int field, int i);
    virtual sFieldWrapper *getFieldWrapper(int field, int i);
};

Register_Class(StartDescriptor);

StartDescriptor::StartDescriptor() : cStructDescriptor("ClusterMessage")
{
}

StartDescriptor::~StartDescriptor()
{
}

int StartDescriptor::getFieldCount()
{
    return baseclassdesc ? 1+baseclassdesc->getFieldCount() : 1;
}

int StartDescriptor::getFieldType(int field)
{
    if (baseclassdesc) {
        if (field < baseclassdesc->getFieldCount())
            return baseclassdesc->getFieldType(field);
        field -= baseclassdesc->getFieldCount();
    }
    switch (field) {
        case 0: return FT_BASIC;
        default: return FT_INVALID;
    }
}

const char *StartDescriptor::getFieldName(int field)
{
    if (baseclassdesc) {
        if (field < baseclassdesc->getFieldCount())
            return baseclassdesc->getFieldName(field);
        field -= baseclassdesc->getFieldCount();
    }
    switch (field) {
        case 0: return "round";
        default: return NULL;
    }
}

const char *StartDescriptor::getFieldTypeString(int field)
{
    if (baseclassdesc) {
        if (field < baseclassdesc->getFieldCount())
            return baseclassdesc->getFieldTypeString(field);
        field -= baseclassdesc->getFieldCount();
    }
    switch (field) {
        case 0: return "int";
        default: return NULL;
    }
}

const char *StartDescriptor::getFieldEnumName(int field)
{
    if (baseclassdesc) {
        if (field < baseclassdesc->getFieldCount())
            return baseclassdesc->getFieldEnumName(field);
        field -= baseclassdesc->getFieldCount();
    }
    switch (field) {
        default: return NULL;
    }
}

int StartDescriptor::getArraySize(int field)
{
    if (baseclassdesc) {
        if (field < baseclassdesc->getFieldCount())
            return baseclassdesc->getArraySize(field);
        field -= baseclassdesc->getFieldCount();
    }
    Start *pp = (Start *)p;
    switch (field) {
        default: return 0;
    }
}

bool StartDescriptor::getFieldAsString(int field, int i, char *resultbuf, int bufsize)
{
    if (baseclassdesc) {
        if (field < baseclassdesc->getFieldCount())
            return baseclassdesc->getFieldAsString(field,i,resultbuf,bufsize);
        field -= baseclassdesc->getFieldCount();
    }
    Start *pp = (Start *)p;
    switch (field) {
        case 0: long2string(pp->getRound(),resultbuf,bufsize); return true;
        default: return false;
    }
}

bool StartDescriptor::setFieldAsString(int field, int i, const char *value)
{
    if (baseclassdesc) {
        if (field < baseclassdesc->getFieldCount())
            return baseclassdesc->setFieldAsString(field,i,value);
        field -= baseclassdesc->getFieldCount();
    }
    Start *pp = (Start *)p;
    switch (field) {
        case 0: pp->setRound(string2long(value)); return true;
        default: return false;
    }
}

const char *StartDescriptor::getFieldStructName(int field)
{
    if (baseclassdesc) {
        if (field < baseclassdesc->getFieldCount())
            return baseclassdesc->getFieldStructName(field);
        field -= baseclassdesc->getFieldCount();
    }
    switch (field) {
        default: return NULL;
    }
}

void *StartDescriptor::getFieldStructPointer(int field, int i)
{
    if (baseclassdesc) {
        if (field < baseclassdesc->getFieldCount())
            return baseclassdesc->getFieldStructPointer(field, i);
        field -= baseclassdesc->getFieldCount();
    }
    Start *pp = (Start *)p;
    switch (field) {
        default: return NULL;
    }
}

sFieldWrapper *StartDescriptor::getFieldWrapper(int field, int i)
{
    return NULL;
}

Register_Class(Status2BSMessage);

Status2BSMessage::Status2BSMessage(const char *name, int kind) : ClusterMessage(name,kind)
{
    this->energy_var = 0;
    this->status_var = 0;
    this->cluster_var = 0;
    this->xpos_var = 0;
    this->ypos_var = 0;
}

Status2BSMessage::Status2BSMessage(const Status2BSMessage& other) : ClusterMessage()
{
    unsigned int i;
    setName(other.name());
    operator=(other);
}

Status2BSMessage::~Status2BSMessage()
{
    unsigned int i;
}

Status2BSMessage& Status2BSMessage::operator=(const Status2BSMessage& other)
{
    if (this==&other) return *this;
    unsigned int i;
    ClusterMessage::operator=(other);
    this->energy_var = other.energy_var;
    this->status_var = other.status_var;
    this->cluster_var = other.cluster_var;
    this->xpos_var = other.xpos_var;
    this->ypos_var = other.ypos_var;
    return *this;
}

void Status2BSMessage::netPack(cCommBuffer *b)
{
    ClusterMessage::netPack(b);
    doPacking(b,this->energy_var);
    doPacking(b,this->status_var);
    doPacking(b,this->cluster_var);
    doPacking(b,this->xpos_var);
    doPacking(b,this->ypos_var);
}

void Status2BSMessage::netUnpack(cCommBuffer *b)
{
    ClusterMessage::netUnpack(b);
    doUnpacking(b,this->energy_var);
    doUnpacking(b,this->status_var);
    doUnpacking(b,this->cluster_var);
    doUnpacking(b,this->xpos_var);
    doUnpacking(b,this->ypos_var);
}

int Status2BSMessage::getEnergy() const
{
    return energy_var;
}

void Status2BSMessage::setEnergy(int energy_var)
{
    this->energy_var = energy_var;
}

int Status2BSMessage::getStatus() const
{
    return status_var;
}

void Status2BSMessage::setStatus(int status_var)
{
    this->status_var = status_var;
}

int Status2BSMessage::getCluster() const
{
    return cluster_var;
}

void Status2BSMessage::setCluster(int cluster_var)
{
    this->cluster_var = cluster_var;
}

int Status2BSMessage::getXpos() const
{
    return xpos_var;
}

void Status2BSMessage::setXpos(int xpos_var)
{
    this->xpos_var = xpos_var;
}

int Status2BSMessage::getYpos() const
{
    return ypos_var;
}

void Status2BSMessage::setYpos(int ypos_var)
{
    this->ypos_var = ypos_var;
}

class Status2BSMessageDescriptor : public cStructDescriptor
{
  public:
    Status2BSMessageDescriptor();
    virtual ~Status2BSMessageDescriptor();
    Status2BSMessageDescriptor& operator=(const Status2BSMessageDescriptor& other);
    virtual cPolymorphic *dup() const {return new Status2BSMessageDescriptor(*this);}

    virtual int getFieldCount();
    virtual const char *getFieldName(int field);
    virtual int getFieldType(int field);
    virtual const char *getFieldTypeString(int field);
    virtual const char *getFieldEnumName(int field);
    virtual int getArraySize(int field);

    virtual bool getFieldAsString(int field, int i, char *resultbuf, int bufsize);
    virtual bool setFieldAsString(int field, int i, const char *value);

    virtual const char *getFieldStructName(int field);
    virtual void *getFieldStructPointer(int field, int i);
    virtual sFieldWrapper *getFieldWrapper(int field, int i);
};

Register_Class(Status2BSMessageDescriptor);

Status2BSMessageDescriptor::Status2BSMessageDescriptor() : cStructDescriptor("ClusterMessage")
{
}

Status2BSMessageDescriptor::~Status2BSMessageDescriptor()
{
}

int Status2BSMessageDescriptor::getFieldCount()
{
    return baseclassdesc ? 5+baseclassdesc->getFieldCount() : 5;
}

int Status2BSMessageDescriptor::getFieldType(int field)
{
    if (baseclassdesc) {
        if (field < baseclassdesc->getFieldCount())
            return baseclassdesc->getFieldType(field);
        field -= baseclassdesc->getFieldCount();
    }
    switch (field) {
        case 0: return FT_BASIC;
        case 1: return FT_BASIC;
        case 2: return FT_BASIC;
        case 3: return FT_BASIC;
        case 4: return FT_BASIC;
        default: return FT_INVALID;
    }
}

const char *Status2BSMessageDescriptor::getFieldName(int field)
{
    if (baseclassdesc) {
        if (field < baseclassdesc->getFieldCount())
            return baseclassdesc->getFieldName(field);
        field -= baseclassdesc->getFieldCount();
    }
    switch (field) {
        case 0: return "energy";
        case 1: return "status";
        case 2: return "cluster";
        case 3: return "xpos";
        case 4: return "ypos";
        default: return NULL;
    }
}

const char *Status2BSMessageDescriptor::getFieldTypeString(int field)
{
    if (baseclassdesc) {
        if (field < baseclassdesc->getFieldCount())
            return baseclassdesc->getFieldTypeString(field);
        field -= baseclassdesc->getFieldCount();
    }
    switch (field) {
        case 0: return "int";
        case 1: return "int";
        case 2: return "int";
        case 3: return "int";
        case 4: return "int";
        default: return NULL;
    }
}

const char *Status2BSMessageDescriptor::getFieldEnumName(int field)
{
    if (baseclassdesc) {
        if (field < baseclassdesc->getFieldCount())
            return baseclassdesc->getFieldEnumName(field);
        field -= baseclassdesc->getFieldCount();
    }
    switch (field) {
        default: return NULL;
    }
}

int Status2BSMessageDescriptor::getArraySize(int field)
{
    if (baseclassdesc) {
        if (field < baseclassdesc->getFieldCount())
            return baseclassdesc->getArraySize(field);
        field -= baseclassdesc->getFieldCount();
    }
    Status2BSMessage *pp = (Status2BSMessage *)p;
    switch (field) {
        default: return 0;
    }
}

bool Status2BSMessageDescriptor::getFieldAsString(int field, int i, char *resultbuf, int bufsize)
{
    if (baseclassdesc) {
        if (field < baseclassdesc->getFieldCount())
            return baseclassdesc->getFieldAsString(field,i,resultbuf,bufsize);
        field -= baseclassdesc->getFieldCount();
    }
    Status2BSMessage *pp = (Status2BSMessage *)p;
    switch (field) {
        case 0: long2string(pp->getEnergy(),resultbuf,bufsize); return true;
        case 1: long2string(pp->getStatus(),resultbuf,bufsize); return true;
        case 2: long2string(pp->getCluster(),resultbuf,bufsize); return true;
        case 3: long2string(pp->getXpos(),resultbuf,bufsize); return true;
        case 4: long2string(pp->getYpos(),resultbuf,bufsize); return true;
        default: return false;
    }
}

bool Status2BSMessageDescriptor::setFieldAsString(int field, int i, const char *value)
{
    if (baseclassdesc) {
        if (field < baseclassdesc->getFieldCount())
            return baseclassdesc->setFieldAsString(field,i,value);
        field -= baseclassdesc->getFieldCount();
    }
    Status2BSMessage *pp = (Status2BSMessage *)p;
    switch (field) {
        case 0: pp->setEnergy(string2long(value)); return true;
        case 1: pp->setStatus(string2long(value)); return true;
        case 2: pp->setCluster(string2long(value)); return true;
        case 3: pp->setXpos(string2long(value)); return true;
        case 4: pp->setYpos(string2long(value)); return true;
        default: return false;
    }
}

const char *Status2BSMessageDescriptor::getFieldStructName(int field)
{
    if (baseclassdesc) {
        if (field < baseclassdesc->getFieldCount())
            return baseclassdesc->getFieldStructName(field);
        field -= baseclassdesc->getFieldCount();
    }
    switch (field) {
        default: return NULL;
    }
}

void *Status2BSMessageDescriptor::getFieldStructPointer(int field, int i)
{
    if (baseclassdesc) {
        if (field < baseclassdesc->getFieldCount())
            return baseclassdesc->getFieldStructPointer(field, i);
        field -= baseclassdesc->getFieldCount();
    }
    Status2BSMessage *pp = (Status2BSMessage *)p;
    switch (field) {
        default: return NULL;
    }
}

sFieldWrapper *Status2BSMessageDescriptor::getFieldWrapper(int field, int i)
{
    return NULL;
}

Register_Class(ClusterHeadMessage);

ClusterHeadMessage::ClusterHeadMessage(const char *name, int kind) : ClusterMessage(name,kind)
{
    unsigned int i;
    for (i=0; i<103; i++)
        this->cHead_var[i] = 0;
}

ClusterHeadMessage::ClusterHeadMessage(const ClusterHeadMessage& other) : ClusterMessage()
{
    unsigned int i;
    setName(other.name());
    operator=(other);
}

ClusterHeadMessage::~ClusterHeadMessage()
{
    unsigned int i;
}

ClusterHeadMessage& ClusterHeadMessage::operator=(const ClusterHeadMessage& other)
{
    if (this==&other) return *this;
    unsigned int i;
    ClusterMessage::operator=(other);
    for (i=0; i<103; i++)
        this->cHead_var[i] = other.cHead_var[i];
    return *this;
}

void ClusterHeadMessage::netPack(cCommBuffer *b)
{
    ClusterMessage::netPack(b);
    doPacking(b,this->cHead_var,103);
}

void ClusterHeadMessage::netUnpack(cCommBuffer *b)
{
    ClusterMessage::netUnpack(b);
    doUnpacking(b,this->cHead_var,103);
}

unsigned int ClusterHeadMessage::getCHeadArraySize() const
{
    return 103;
}

int ClusterHeadMessage::getCHead(unsigned int k) const
{
    if (k>=103) throw new cException("Array of size 103 indexed by %d", k);
    return cHead_var[k];
}

void ClusterHeadMessage::setCHead(unsigned int k, int cHead_var)
{
    if (k>=103) throw new cException("Array of size 103 indexed by %d", k);
    this->cHead_var[k] = cHead_var;
}

class ClusterHeadMessageDescriptor : public cStructDescriptor
{
  public:
    ClusterHeadMessageDescriptor();
    virtual ~ClusterHeadMessageDescriptor();
    ClusterHeadMessageDescriptor& operator=(const ClusterHeadMessageDescriptor& other);
    virtual cPolymorphic *dup() const {return new ClusterHeadMessageDescriptor(*this);}

    virtual int getFieldCount();
    virtual const char *getFieldName(int field);
    virtual int getFieldType(int field);
    virtual const char *getFieldTypeString(int field);
    virtual const char *getFieldEnumName(int field);
    virtual int getArraySize(int field);

    virtual bool getFieldAsString(int field, int i, char *resultbuf, int bufsize);
    virtual bool setFieldAsString(int field, int i, const char *value);

    virtual const char *getFieldStructName(int field);
    virtual void *getFieldStructPointer(int field, int i);
    virtual sFieldWrapper *getFieldWrapper(int field, int i);
};

Register_Class(ClusterHeadMessageDescriptor);

ClusterHeadMessageDescriptor::ClusterHeadMessageDescriptor() : cStructDescriptor("ClusterMessage")
{
}

ClusterHeadMessageDescriptor::~ClusterHeadMessageDescriptor()
{
}

int ClusterHeadMessageDescriptor::getFieldCount()
{
    return baseclassdesc ? 1+baseclassdesc->getFieldCount() : 1;
}

int ClusterHeadMessageDescriptor::getFieldType(int field)
{
    if (baseclassdesc) {
        if (field < baseclassdesc->getFieldCount())
            return baseclassdesc->getFieldType(field);
        field -= baseclassdesc->getFieldCount();
    }
    switch (field) {
        case 0: return FT_BASIC_ARRAY;
        default: return FT_INVALID;
    }
}

const char *ClusterHeadMessageDescriptor::getFieldName(int field)
{
    if (baseclassdesc) {
        if (field < baseclassdesc->getFieldCount())
            return baseclassdesc->getFieldName(field);
        field -= baseclassdesc->getFieldCount();
    }
    switch (field) {
        case 0: return "cHead";
        default: return NULL;
    }
}

const char *ClusterHeadMessageDescriptor::getFieldTypeString(int field)
{
    if (baseclassdesc) {
        if (field < baseclassdesc->getFieldCount())
            return baseclassdesc->getFieldTypeString(field);
        field -= baseclassdesc->getFieldCount();
    }
    switch (field) {
        case 0: return "int";
        default: return NULL;
    }
}

const char *ClusterHeadMessageDescriptor::getFieldEnumName(int field)
{
    if (baseclassdesc) {
        if (field < baseclassdesc->getFieldCount())
            return baseclassdesc->getFieldEnumName(field);
        field -= baseclassdesc->getFieldCount();
    }
    switch (field) {
        default: return NULL;
    }
}

int ClusterHeadMessageDescriptor::getArraySize(int field)
{
    if (baseclassdesc) {
        if (field < baseclassdesc->getFieldCount())
            return baseclassdesc->getArraySize(field);
        field -= baseclassdesc->getFieldCount();
    }
    ClusterHeadMessage *pp = (ClusterHeadMessage *)p;
    switch (field) {
        case 0: return 103;
        default: return 0;
    }
}

bool ClusterHeadMessageDescriptor::getFieldAsString(int field, int i, char *resultbuf, int bufsize)
{
    if (baseclassdesc) {
        if (field < baseclassdesc->getFieldCount())
            return baseclassdesc->getFieldAsString(field,i,resultbuf,bufsize);
        field -= baseclassdesc->getFieldCount();
    }
    ClusterHeadMessage *pp = (ClusterHeadMessage *)p;
    switch (field) {
        case 0: long2string(pp->getCHead(i),resultbuf,bufsize); return true;
        default: return false;
    }
}

bool ClusterHeadMessageDescriptor::setFieldAsString(int field, int i, const char *value)
{
    if (baseclassdesc) {
        if (field < baseclassdesc->getFieldCount())
            return baseclassdesc->setFieldAsString(field,i,value);
        field -= baseclassdesc->getFieldCount();
    }
    ClusterHeadMessage *pp = (ClusterHeadMessage *)p;
    switch (field) {
        case 0: pp->setCHead(i,string2long(value)); return true;
        default: return false;
    }
}

const char *ClusterHeadMessageDescriptor::getFieldStructName(int field)
{
    if (baseclassdesc) {
        if (field < baseclassdesc->getFieldCount())
            return baseclassdesc->getFieldStructName(field);
        field -= baseclassdesc->getFieldCount();
    }
    switch (field) {
        default: return NULL;
    }
}

void *ClusterHeadMessageDescriptor::getFieldStructPointer(int field, int i)
{
    if (baseclassdesc) {
        if (field < baseclassdesc->getFieldCount())
            return baseclassdesc->getFieldStructPointer(field, i);
        field -= baseclassdesc->getFieldCount();
    }
    ClusterHeadMessage *pp = (ClusterHeadMessage *)p;
    switch (field) {
        default: return NULL;
    }
}

sFieldWrapper *ClusterHeadMessageDescriptor::getFieldWrapper(int field, int i)
{
    return NULL;
}

Register_Class(TDMAMessage);

TDMAMessage::TDMAMessage(const char *name, int kind) : ClusterMessage(name,kind)
{
    unsigned int i;
    this->frames_var = 0;
    this->frameTime_var = 0;
    for (i=0; i<103; i++)
        this->tdma_var[i] = 0;
}

TDMAMessage::TDMAMessage(const TDMAMessage& other) : ClusterMessage()
{
    unsigned int i;
    setName(other.name());
    operator=(other);
}

TDMAMessage::~TDMAMessage()
{
    unsigned int i;
}

TDMAMessage& TDMAMessage::operator=(const TDMAMessage& other)
{
    if (this==&other) return *this;
    unsigned int i;
    ClusterMessage::operator=(other);
    this->frames_var = other.frames_var;
    this->frameTime_var = other.frameTime_var;
    for (i=0; i<103; i++)
        this->tdma_var[i] = other.tdma_var[i];
    return *this;
}

void TDMAMessage::netPack(cCommBuffer *b)
{
    ClusterMessage::netPack(b);
    doPacking(b,this->frames_var);
    doPacking(b,this->frameTime_var);
    doPacking(b,this->tdma_var,103);
}

void TDMAMessage::netUnpack(cCommBuffer *b)
{
    ClusterMessage::netUnpack(b);
    doUnpacking(b,this->frames_var);
    doUnpacking(b,this->frameTime_var);
    doUnpacking(b,this->tdma_var,103);
}

int TDMAMessage::getFrames() const
{
    return frames_var;
}

void TDMAMessage::setFrames(int frames_var)
{
    this->frames_var = frames_var;
}

int TDMAMessage::getFrameTime() const
{
    return frameTime_var;
}

void TDMAMessage::setFrameTime(int frameTime_var)
{
    this->frameTime_var = frameTime_var;
}

unsigned int TDMAMessage::getTdmaArraySize() const
{
    return 103;
}

int TDMAMessage::getTdma(unsigned int k) const
{
    if (k>=103) throw new cException("Array of size 103 indexed by %d", k);
    return tdma_var[k];
}

void TDMAMessage::setTdma(unsigned int k, int tdma_var)
{
    if (k>=103) throw new cException("Array of size 103 indexed by %d", k);
    this->tdma_var[k] = tdma_var;
}

class TDMAMessageDescriptor : public cStructDescriptor
{
  public:
    TDMAMessageDescriptor();
    virtual ~TDMAMessageDescriptor();
    TDMAMessageDescriptor& operator=(const TDMAMessageDescriptor& other);
    virtual cPolymorphic *dup() const {return new TDMAMessageDescriptor(*this);}

    virtual int getFieldCount();
    virtual const char *getFieldName(int field);
    virtual int getFieldType(int field);
    virtual const char *getFieldTypeString(int field);
    virtual const char *getFieldEnumName(int field);
    virtual int getArraySize(int field);

    virtual bool getFieldAsString(int field, int i, char *resultbuf, int bufsize);
    virtual bool setFieldAsString(int field, int i, const char *value);

    virtual const char *getFieldStructName(int field);
    virtual void *getFieldStructPointer(int field, int i);
    virtual sFieldWrapper *getFieldWrapper(int field, int i);
};

Register_Class(TDMAMessageDescriptor);

TDMAMessageDescriptor::TDMAMessageDescriptor() : cStructDescriptor("ClusterMessage")
{
}

TDMAMessageDescriptor::~TDMAMessageDescriptor()
{
}

int TDMAMessageDescriptor::getFieldCount()
{
    return baseclassdesc ? 3+baseclassdesc->getFieldCount() : 3;
}

int TDMAMessageDescriptor::getFieldType(int field)
{
    if (baseclassdesc) {
        if (field < baseclassdesc->getFieldCount())
            return baseclassdesc->getFieldType(field);
        field -= baseclassdesc->getFieldCount();
    }
    switch (field) {
        case 0: return FT_BASIC;
        case 1: return FT_BASIC;
        case 2: return FT_BASIC_ARRAY;
        default: return FT_INVALID;
    }
}

const char *TDMAMessageDescriptor::getFieldName(int field)
{
    if (baseclassdesc) {
        if (field < baseclassdesc->getFieldCount())
            return baseclassdesc->getFieldName(field);
        field -= baseclassdesc->getFieldCount();
    }
    switch (field) {
        case 0: return "frames";
        case 1: return "frameTime";
        case 2: return "tdma";
        default: return NULL;
    }
}

const char *TDMAMessageDescriptor::getFieldTypeString(int field)
{
    if (baseclassdesc) {
        if (field < baseclassdesc->getFieldCount())
            return baseclassdesc->getFieldTypeString(field);
        field -= baseclassdesc->getFieldCount();
    }
    switch (field) {
        case 0: return "int";
        case 1: return "int";
        case 2: return "int";
        default: return NULL;
    }
}

const char *TDMAMessageDescriptor::getFieldEnumName(int field)
{
    if (baseclassdesc) {
        if (field < baseclassdesc->getFieldCount())
            return baseclassdesc->getFieldEnumName(field);
        field -= baseclassdesc->getFieldCount();
    }
    switch (field) {
        default: return NULL;
    }
}

int TDMAMessageDescriptor::getArraySize(int field)
{
    if (baseclassdesc) {
        if (field < baseclassdesc->getFieldCount())
            return baseclassdesc->getArraySize(field);
        field -= baseclassdesc->getFieldCount();
    }
    TDMAMessage *pp = (TDMAMessage *)p;
    switch (field) {
        case 2: return 103;
        default: return 0;
    }
}

bool TDMAMessageDescriptor::getFieldAsString(int field, int i, char *resultbuf, int bufsize)
{
    if (baseclassdesc) {
        if (field < baseclassdesc->getFieldCount())
            return baseclassdesc->getFieldAsString(field,i,resultbuf,bufsize);
        field -= baseclassdesc->getFieldCount();
    }
    TDMAMessage *pp = (TDMAMessage *)p;
    switch (field) {
        case 0: long2string(pp->getFrames(),resultbuf,bufsize); return true;
        case 1: long2string(pp->getFrameTime(),resultbuf,bufsize); return true;
        case 2: long2string(pp->getTdma(i),resultbuf,bufsize); return true;
        default: return false;
    }
}

bool TDMAMessageDescriptor::setFieldAsString(int field, int i, const char *value)
{
    if (baseclassdesc) {
        if (field < baseclassdesc->getFieldCount())
            return baseclassdesc->setFieldAsString(field,i,value);
        field -= baseclassdesc->getFieldCount();
    }
    TDMAMessage *pp = (TDMAMessage *)p;
    switch (field) {
        case 0: pp->setFrames(string2long(value)); return true;
        case 1: pp->setFrameTime(string2long(value)); return true;
        case 2: pp->setTdma(i,string2long(value)); return true;
        default: return false;
    }
}

const char *TDMAMessageDescriptor::getFieldStructName(int field)
{
    if (baseclassdesc) {
        if (field < baseclassdesc->getFieldCount())
            return baseclassdesc->getFieldStructName(field);
        field -= baseclassdesc->getFieldCount();
    }
    switch (field) {
        default: return NULL;
    }
}

void *TDMAMessageDescriptor::getFieldStructPointer(int field, int i)
{
    if (baseclassdesc) {
        if (field < baseclassdesc->getFieldCount())
            return baseclassdesc->getFieldStructPointer(field, i);
        field -= baseclassdesc->getFieldCount();
    }
    TDMAMessage *pp = (TDMAMessage *)p;
    switch (field) {
        default: return NULL;
    }
}

sFieldWrapper *TDMAMessageDescriptor::getFieldWrapper(int field, int i)
{
    return NULL;
}

Register_Class(DataToCHMessage);

DataToCHMessage::DataToCHMessage(const char *name, int kind) : ClusterMessage(name,kind)
{
    this->data_var = 0;
}

DataToCHMessage::DataToCHMessage(const DataToCHMessage& other) : ClusterMessage()
{
    unsigned int i;
    setName(other.name());
    operator=(other);
}

DataToCHMessage::~DataToCHMessage()
{
    unsigned int i;
}

DataToCHMessage& DataToCHMessage::operator=(const DataToCHMessage& other)
{
    if (this==&other) return *this;
    unsigned int i;
    ClusterMessage::operator=(other);
    this->data_var = other.data_var;
    return *this;
}

void DataToCHMessage::netPack(cCommBuffer *b)
{
    ClusterMessage::netPack(b);
    doPacking(b,this->data_var);
}

void DataToCHMessage::netUnpack(cCommBuffer *b)
{
    ClusterMessage::netUnpack(b);
    doUnpacking(b,this->data_var);
}

int DataToCHMessage::getData() const
{
    return data_var;
}

void DataToCHMessage::setData(int data_var)
{
    this->data_var = data_var;
}

class DataToCHMessageDescriptor : public cStructDescriptor
{
  public:
    DataToCHMessageDescriptor();
    virtual ~DataToCHMessageDescriptor();
    DataToCHMessageDescriptor& operator=(const DataToCHMessageDescriptor& other);
    virtual cPolymorphic *dup() const {return new DataToCHMessageDescriptor(*this);}

    virtual int getFieldCount();
    virtual const char *getFieldName(int field);
    virtual int getFieldType(int field);
    virtual const char *getFieldTypeString(int field);
    virtual const char *getFieldEnumName(int field);
    virtual int getArraySize(int field);

    virtual bool getFieldAsString(int field, int i, char *resultbuf, int bufsize);
    virtual bool setFieldAsString(int field, int i, const char *value);

    virtual const char *getFieldStructName(int field);
    virtual void *getFieldStructPointer(int field, int i);
    virtual sFieldWrapper *getFieldWrapper(int field, int i);
};

Register_Class(DataToCHMessageDescriptor);

DataToCHMessageDescriptor::DataToCHMessageDescriptor() : cStructDescriptor("ClusterMessage")
{
}

DataToCHMessageDescriptor::~DataToCHMessageDescriptor()
{
}

int DataToCHMessageDescriptor::getFieldCount()
{
    return baseclassdesc ? 1+baseclassdesc->getFieldCount() : 1;
}

int DataToCHMessageDescriptor::getFieldType(int field)
{
    if (baseclassdesc) {
        if (field < baseclassdesc->getFieldCount())
            return baseclassdesc->getFieldType(field);
        field -= baseclassdesc->getFieldCount();
    }
    switch (field) {
        case 0: return FT_BASIC;
        default: return FT_INVALID;
    }
}

const char *DataToCHMessageDescriptor::getFieldName(int field)
{
    if (baseclassdesc) {
        if (field < baseclassdesc->getFieldCount())
            return baseclassdesc->getFieldName(field);
        field -= baseclassdesc->getFieldCount();
    }
    switch (field) {
        case 0: return "data";
        default: return NULL;
    }
}

const char *DataToCHMessageDescriptor::getFieldTypeString(int field)
{
    if (baseclassdesc) {
        if (field < baseclassdesc->getFieldCount())
            return baseclassdesc->getFieldTypeString(field);
        field -= baseclassdesc->getFieldCount();
    }
    switch (field) {
        case 0: return "int";
        default: return NULL;
    }
}

const char *DataToCHMessageDescriptor::getFieldEnumName(int field)
{
    if (baseclassdesc) {
        if (field < baseclassdesc->getFieldCount())
            return baseclassdesc->getFieldEnumName(field);
        field -= baseclassdesc->getFieldCount();
    }
    switch (field) {
        default: return NULL;
    }
}

int DataToCHMessageDescriptor::getArraySize(int field)
{
    if (baseclassdesc) {
        if (field < baseclassdesc->getFieldCount())
            return baseclassdesc->getArraySize(field);
        field -= baseclassdesc->getFieldCount();
    }
    DataToCHMessage *pp = (DataToCHMessage *)p;
    switch (field) {
        default: return 0;
    }
}

bool DataToCHMessageDescriptor::getFieldAsString(int field, int i, char *resultbuf, int bufsize)
{
    if (baseclassdesc) {
        if (field < baseclassdesc->getFieldCount())
            return baseclassdesc->getFieldAsString(field,i,resultbuf,bufsize);
        field -= baseclassdesc->getFieldCount();
    }
    DataToCHMessage *pp = (DataToCHMessage *)p;
    switch (field) {
        case 0: long2string(pp->getData(),resultbuf,bufsize); return true;
        default: return false;
    }
}

bool DataToCHMessageDescriptor::setFieldAsString(int field, int i, const char *value)
{
    if (baseclassdesc) {
        if (field < baseclassdesc->getFieldCount())
            return baseclassdesc->setFieldAsString(field,i,value);
        field -= baseclassdesc->getFieldCount();
    }
    DataToCHMessage *pp = (DataToCHMessage *)p;
    switch (field) {
        case 0: pp->setData(string2long(value)); return true;
        default: return false;
    }
}

const char *DataToCHMessageDescriptor::getFieldStructName(int field)
{
    if (baseclassdesc) {
        if (field < baseclassdesc->getFieldCount())
            return baseclassdesc->getFieldStructName(field);
        field -= baseclassdesc->getFieldCount();
    }
    switch (field) {
        default: return NULL;
    }
}

void *DataToCHMessageDescriptor::getFieldStructPointer(int field, int i)
{
    if (baseclassdesc) {
        if (field < baseclassdesc->getFieldCount())
            return baseclassdesc->getFieldStructPointer(field, i);
        field -= baseclassdesc->getFieldCount();
    }
    DataToCHMessage *pp = (DataToCHMessage *)p;
    switch (field) {
        default: return NULL;
    }
}

sFieldWrapper *DataToCHMessageDescriptor::getFieldWrapper(int field, int i)
{
    return NULL;
}

Register_Class(Data2BSMessage);

Data2BSMessage::Data2BSMessage(const char *name, int kind) : ClusterMessage(name,kind)
{
    this->data_var = 0;
}

Data2BSMessage::Data2BSMessage(const Data2BSMessage& other) : ClusterMessage()
{
    unsigned int i;
    setName(other.name());
    operator=(other);
}

Data2BSMessage::~Data2BSMessage()
{
    unsigned int i;
}

Data2BSMessage& Data2BSMessage::operator=(const Data2BSMessage& other)
{
    if (this==&other) return *this;
    unsigned int i;
    ClusterMessage::operator=(other);
    this->data_var = other.data_var;
    return *this;
}

void Data2BSMessage::netPack(cCommBuffer *b)
{
    ClusterMessage::netPack(b);
    doPacking(b,this->data_var);
}

void Data2BSMessage::netUnpack(cCommBuffer *b)
{
    ClusterMessage::netUnpack(b);
    doUnpacking(b,this->data_var);
}

int Data2BSMessage::getData() const
{
    return data_var;
}

void Data2BSMessage::setData(int data_var)
{
    this->data_var = data_var;
}

class Data2BSMessageDescriptor : public cStructDescriptor
{
  public:
    Data2BSMessageDescriptor();
    virtual ~Data2BSMessageDescriptor();
    Data2BSMessageDescriptor& operator=(const Data2BSMessageDescriptor& other);
    virtual cPolymorphic *dup() const {return new Data2BSMessageDescriptor(*this);}

    virtual int getFieldCount();
    virtual const char *getFieldName(int field);
    virtual int getFieldType(int field);
    virtual const char *getFieldTypeString(int field);
    virtual const char *getFieldEnumName(int field);
    virtual int getArraySize(int field);

    virtual bool getFieldAsString(int field, int i, char *resultbuf, int bufsize);
    virtual bool setFieldAsString(int field, int i, const char *value);

    virtual const char *getFieldStructName(int field);
    virtual void *getFieldStructPointer(int field, int i);
    virtual sFieldWrapper *getFieldWrapper(int field, int i);
};

Register_Class(Data2BSMessageDescriptor);

Data2BSMessageDescriptor::Data2BSMessageDescriptor() : cStructDescriptor("ClusterMessage")
{
}

Data2BSMessageDescriptor::~Data2BSMessageDescriptor()
{
}

int Data2BSMessageDescriptor::getFieldCount()
{
    return baseclassdesc ? 1+baseclassdesc->getFieldCount() : 1;
}

int Data2BSMessageDescriptor::getFieldType(int field)
{
    if (baseclassdesc) {
        if (field < baseclassdesc->getFieldCount())
            return baseclassdesc->getFieldType(field);
        field -= baseclassdesc->getFieldCount();
    }
    switch (field) {
        case 0: return FT_BASIC;
        default: return FT_INVALID;
    }
}

const char *Data2BSMessageDescriptor::getFieldName(int field)
{
    if (baseclassdesc) {
        if (field < baseclassdesc->getFieldCount())
            return baseclassdesc->getFieldName(field);
        field -= baseclassdesc->getFieldCount();
    }
    switch (field) {
        case 0: return "data";
        default: return NULL;
    }
}

const char *Data2BSMessageDescriptor::getFieldTypeString(int field)
{
    if (baseclassdesc) {
        if (field < baseclassdesc->getFieldCount())
            return baseclassdesc->getFieldTypeString(field);
        field -= baseclassdesc->getFieldCount();
    }
    switch (field) {
        case 0: return "int";
        default: return NULL;
    }
}

const char *Data2BSMessageDescriptor::getFieldEnumName(int field)
{
    if (baseclassdesc) {
        if (field < baseclassdesc->getFieldCount())
            return baseclassdesc->getFieldEnumName(field);
        field -= baseclassdesc->getFieldCount();
    }
    switch (field) {
        default: return NULL;
    }
}

int Data2BSMessageDescriptor::getArraySize(int field)
{
    if (baseclassdesc) {
        if (field < baseclassdesc->getFieldCount())
            return baseclassdesc->getArraySize(field);
        field -= baseclassdesc->getFieldCount();
    }
    Data2BSMessage *pp = (Data2BSMessage *)p;
    switch (field) {
        default: return 0;
    }
}

bool Data2BSMessageDescriptor::getFieldAsString(int field, int i, char *resultbuf, int bufsize)
{
    if (baseclassdesc) {
        if (field < baseclassdesc->getFieldCount())
            return baseclassdesc->getFieldAsString(field,i,resultbuf,bufsize);
        field -= baseclassdesc->getFieldCount();
    }
    Data2BSMessage *pp = (Data2BSMessage *)p;
    switch (field) {
        case 0: long2string(pp->getData(),resultbuf,bufsize); return true;
        default: return false;
    }
}

bool Data2BSMessageDescriptor::setFieldAsString(int field, int i, const char *value)
{
    if (baseclassdesc) {
        if (field < baseclassdesc->getFieldCount())
            return baseclassdesc->setFieldAsString(field,i,value);
        field -= baseclassdesc->getFieldCount();
    }
    Data2BSMessage *pp = (Data2BSMessage *)p;
    switch (field) {
        case 0: pp->setData(string2long(value)); return true;
        default: return false;
    }
}

const char *Data2BSMessageDescriptor::getFieldStructName(int field)
{
    if (baseclassdesc) {
        if (field < baseclassdesc->getFieldCount())
            return baseclassdesc->getFieldStructName(field);
        field -= baseclassdesc->getFieldCount();
    }
    switch (field) {
        default: return NULL;
    }
}

void *Data2BSMessageDescriptor::getFieldStructPointer(int field, int i)
{
    if (baseclassdesc) {
        if (field < baseclassdesc->getFieldCount())
            return baseclassdesc->getFieldStructPointer(field, i);
        field -= baseclassdesc->getFieldCount();
    }
    Data2BSMessage *pp = (Data2BSMessage *)p;
    switch (field) {
        default: return NULL;
    }
}

sFieldWrapper *Data2BSMessageDescriptor::getFieldWrapper(int field, int i)
{
    return NULL;
}

